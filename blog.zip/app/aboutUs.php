<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class aboutUs extends Model
{
    protected $fillable =['text'];
}

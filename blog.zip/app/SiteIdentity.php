<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteIdentity extends Model
{
    protected $fillable =['copyright','logo','footer_txt'];
}

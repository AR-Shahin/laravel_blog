<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SocialLink extends Model
{
    protected $fillable =['fb','tw','text','address','phone','email','linke','insta','pin'];
}
@include('includes.front_navbar')
@yield('main_section')
@include('includes.front_footer')
@include('sweetalert::alert')

<p style="padding:100px;">
   name  {{$name}}
   email  {{$email}}
   Text   {{$text}}
</p>